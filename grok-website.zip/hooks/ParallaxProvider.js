import { ParallaxProvider } from 'react-scroll-parallax';

export default ParallaxProvider;
